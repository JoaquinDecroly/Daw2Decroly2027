EXAMEN MP_0614 - UD1 - MODELO C
Proyecto Maven WAR para Apache Tomcat 9.

REQUISITOS
- JDK 8 o superior (en Eclipse, configurar un JDK).
- Eclipse IDE for Enterprise Java and Web Developers.
- Apache Tomcat 9 configurado en Eclipse.
- Maven (Eclipse suele incluir integración Maven).

IMPORTAR EN ECLIPSE
1. Descomprime el ZIP.
2. Abre Eclipse.
3. File > Import > Maven > Existing Maven Projects.
4. Selecciona la carpeta Examen_MP0614_Decroly y pulsa Finish.
5. Si aparecen errores de dependencias: botón derecho en el proyecto > Maven > Update Project.

CONFIGURAR TOMCAT
1. Abre la vista Servers: Window > Show View > Servers.
2. Si no aparece Tomcat 9: botón derecho > New > Server.
3. Selecciona Apache > Tomcat v9.0 Server.
4. Indica la carpeta donde está instalado Tomcat 9.
5. Selecciona el JRE/JDK configurado y termina.
6. Botón derecho en el servidor > Add and Remove... > añade Decroly > Finish.
7. Botón derecho > Start.

PROBAR
- Web principal: http://localhost:8080/Decroly/
- Formulario contador: http://localhost:8080/Decroly/contador
- La página principal contiene un enlace al contador.

PRUEBA OBLIGATORIA DEL EXAMEN
Copia este texto en el formulario:
¿No es verdad, ángel de amor, que en esta apartada orilla más pura la luna brilla y se respira mejor?
Pulsa Contar caracteres. El servlet mostrará la longitud exacta y los caracteres restantes hasta 280.

NOTA SOBRE LAS CAPTURAS
Las capturas exigidas deben hacerse en tu propio ordenador con Tomcat arrancado. No se incluyen capturas ficticias de un servidor que no se ha ejecutado en tu equipo.
