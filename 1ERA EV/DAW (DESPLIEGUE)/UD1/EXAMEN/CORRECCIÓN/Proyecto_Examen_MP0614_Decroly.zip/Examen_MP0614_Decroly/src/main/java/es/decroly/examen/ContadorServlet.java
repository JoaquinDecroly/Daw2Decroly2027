package es.decroly.examen;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/contador")
public class ContadorServlet extends HttpServlet {

    private static final int LIMITE = 280;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        response.setCharacterEncoding("UTF-8");

        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE html>");
        out.println("<html lang='es'><head><meta charset='UTF-8'>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1'>");
        out.println("<title>Contador de caracteres</title>");
        out.println("<link rel='stylesheet' href='" + request.getContextPath() + "/css/estilos.css'>");
        out.println("<style>");
        out.println("body{padding:35px 6%;}.caja{max-width:760px;margin:35px auto;background:white;padding:28px;border-radius:16px;box-shadow:0 8px 28px #15365b18;}");
        out.println("textarea{width:100%;min-height:150px;padding:14px;border:1px solid #b9cbe0;border-radius:9px;font:1rem Arial;}");
        out.println("button{border:0;background:#126bd0;color:white;padding:12px 20px;border-radius:8px;font-weight:bold;cursor:pointer;}");
        out.println(".resultado{margin-top:20px;padding:16px;background:#eaf4ff;border-radius:10px;}");
        out.println(".volver{display:inline-block;margin-top:18px;color:#126bd0;}");
        out.println("</style></head><body>");
        out.println("<div class='caja'><h1>Contador de caracteres</h1>");
        out.println("<p>Escribe un texto y calcularemos su longitud y los caracteres que faltan para llegar a 280.</p>");
        out.println("<form method='post' action='" + request.getContextPath() + "/contador'>");
        out.println("<label for='texto'><strong>Introduce tu texto:</strong></label><br><br>");
        out.println("<textarea id='texto' name='texto' required></textarea><br><br>");
        out.println("<button type='submit'>Contar caracteres</button></form>");
        out.println("<a class='volver' href='" + request.getContextPath() + "/index.html'>← Volver a Decroly</a>");
        out.println("</div></body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        response.setCharacterEncoding("UTF-8");

        String texto = request.getParameter("texto");
        if (texto == null) {
            texto = "";
        }

        int caracteres = texto.length();
        int faltan = Math.max(0, LIMITE - caracteres);

        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE html>");
        out.println("<html lang='es'><head><meta charset='UTF-8'>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1'>");
        out.println("<title>Resultado del contador</title>");
        out.println("<style>");
        out.println("body{font-family:Arial,sans-serif;background:#f4f8ff;color:#172554;padding:35px 6%;}");
        out.println(".caja{max-width:760px;margin:35px auto;background:white;padding:28px;border-radius:16px;box-shadow:0 8px 28px #15365b18;}");
        out.println(".resultado{padding:18px;background:#eaf4ff;border-left:5px solid #126bd0;border-radius:8px;}");
        out.println(".texto{white-space:pre-wrap;overflow-wrap:anywhere;background:#f7f9fc;padding:14px;border-radius:8px;}");
        out.println("a{display:inline-block;margin-top:18px;color:#126bd0;}");
        out.println("</style></head><body><div class='caja'>");
        out.println("<h1>Resultado del contador</h1>");
        out.println("<div class='resultado'><h2>Tu texto tiene " + caracteres + " caracteres.</h2>");
        if (caracteres <= LIMITE) {
            out.println("<p>Te faltan <strong>" + faltan + " caracteres</strong> para llegar al límite de 280.</p>");
        } else {
            out.println("<p>Has superado el límite de 280 caracteres en <strong>" + (caracteres - LIMITE) + "</strong>.</p>");
            out.println("<p>Caracteres que faltan para llegar al límite: 0.</p>");
        }
        out.println("</div><h3>Texto introducido</h3><div class='texto'>");
        out.println(escaparHtml(texto));
        out.println("</div><a href='" + request.getContextPath() + "/contador'>← Volver a probar</a>");
        out.println("<br><a href='" + request.getContextPath() + "/index.html'>Volver a Decroly</a>");
        out.println("</div></body></html>");
    }

    private String escaparHtml(String texto) {
        return texto.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;");
    }
}
